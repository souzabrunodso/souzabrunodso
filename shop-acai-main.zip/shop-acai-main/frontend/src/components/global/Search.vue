<template>
  <div class="content-inputs search-input">
    <vs-input label-placeholder="Buscar por algo..." />
  </div>
</template>

<style lang="scss">
.search-input {
  max-width: 400px;
  width: 100%;
}

.vs-input {
  width: 100% !important;
}
</style>