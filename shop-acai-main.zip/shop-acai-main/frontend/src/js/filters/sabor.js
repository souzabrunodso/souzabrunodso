export default (param) => {
  switch (param) {
    case 1:
      return "Morango";

    case 2:
      return "Banana";

    case 3:
      return "Kiwi";

    default:
      return "Indefinido";
  }
};